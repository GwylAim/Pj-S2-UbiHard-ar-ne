#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

/*

Constantes utiles pour le programme
*/

#ifndef DEF_CONSTANTES
#define DEF_CONSTANTES

    #define TAILLE_BLOC         34 // Taille d'un bloc (carr�) en pixels
    #define NB_BLOCS_LARGEUR    12
    #define NB_BLOCS_HAUTEUR    12
    #define LARGEUR_FENETRE     TAILLE_BLOC * NB_BLOCS_LARGEUR   /// define = valeur pour constante (aliases)
    #define HAUTEUR_FENETRE     TAILLE_BLOC * NB_BLOCS_HAUTEUR   /// enum = pas de valeur pr�cise (aliases)

    enum {HAUT, BAS, GAUCHE, DROITE};
    enum {VIDE, MUR, AGENT}; /// il reste le tir � impl�menter

#endif

/*
----------
----------

Prototype de la fonction pour charger la carte
*/

#ifndef DEF_FICHIERS
#define DEF_FICHIERS

    int chargerCarte(int niveau[][NB_BLOCS_HAUTEUR]);

#endif


#ifndef DEF_JEU
#define DEF_JEU

    void jouer(SDL_Surface* ecran); // prototype fonction jouer
    void deplacerJoueur(int carte[][NB_BLOCS_HAUTEUR], SDL_Rect *pos, int direction);


#endif

int chargerCarte(int niveau[][NB_BLOCS_HAUTEUR])
{
    FILE* fichier = NULL;
    char ligneFichier[NB_BLOCS_LARGEUR * NB_BLOCS_HAUTEUR + 1] = {0};
    int i = 0, j = 0;

    fichier = fopen("carte.lvl", "r");
    if (fichier == NULL)
        return 0;

    fgets(ligneFichier, NB_BLOCS_LARGEUR * NB_BLOCS_HAUTEUR + 1, fichier);

    for (i = 0 ; i < NB_BLOCS_LARGEUR ; i++)
    {
        for (j = 0 ; j < NB_BLOCS_HAUTEUR ; j++)
        {
            switch (ligneFichier[(i * NB_BLOCS_LARGEUR) + j])
            {
                case '0':
                    niveau[j][i] = 0;
                    break;
                case '1':
                    niveau[j][i] = 1;
                    break;
                case '2':
                    niveau[j][i] = 2;
                    break;
                case '3':
                    niveau[j][i] = 3;
                    break;
                case '4':
                    niveau[j][i] = 4;
                    break;
            }
        }
    }

    fclose(fichier);
    return 1;
}


void jouer(SDL_Surface* ecran)
{
    SDL_Surface *agent[4] = {NULL}; // 4 surfaces pour chacune des directions de l'agent
    SDL_Surface *mur = NULL, *caseVide = NULL, *agentActuel = NULL;
    SDL_Rect position, positionJoueur;
    SDL_Event event;

    int continuer = 1, i = 0, j = 0;
    int carte[NB_BLOCS_LARGEUR][NB_BLOCS_HAUTEUR] = {0};

    // Chargement des sprites (d�cors, personnages...)
    mur = IMG_Load("mur.bmp");
    caseVide = IMG_Load("case_vide.bmp");
    agent[BAS] = IMG_Load("agent_bas.bmp");
    agent[GAUCHE] = IMG_Load("agent_gauche.bmp");
    agent[HAUT] = IMG_Load("agent_haut.bmp");
    agent[DROITE] = IMG_Load("agent_droite.bmp");

    agentActuel = agent[BAS]; // L'agent sera dirig� vers le bas au d�part (pourquoi pas random ?)

    // Chargement du niveau
    if (!chargerCarte(carte))
        exit(EXIT_FAILURE); // On arr�te le jeu si on n'a pas pu charger le niveau

    // Recherche de la position de l'agent au d�part
    for (i = 0 ; i < NB_BLOCS_LARGEUR ; i++)
    {
        for (j = 0 ; j < NB_BLOCS_HAUTEUR ; j++)
        {
            if (carte[i][j] == AGENT) // Si l'agent se trouve � cette position sur la carte ....
            {
                positionJoueur.x = i;
                positionJoueur.y = j;
                carte[i][j] = VIDE;
            }
        }
    }


    SDL_EnableKeyRepeat(100, 100); // Pour appuyer sur les touches n fois de suite (r�p�tition)

    while (continuer)
    {
        SDL_WaitEvent(&event);
switch(event.type)
{
    case SDL_QUIT:
        continuer = 0;
        break;
    case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
            case SDLK_ESCAPE:
                continuer = 0;
                break;
            case SDLK_UP:
                agentActuel = agent[HAUT];
                deplacerJoueur(carte, &positionJoueur, HAUT);
                break;
            case SDLK_DOWN:
                agentActuel = agent[BAS];
                deplacerJoueur(carte, &positionJoueur, BAS);
                break;
            case SDLK_RIGHT:
                agentActuel = agent[DROITE];
                deplacerJoueur(carte, &positionJoueur, DROITE);
                break;
            case SDLK_LEFT:
                agentActuel = agent[GAUCHE];
                deplacerJoueur(carte, &positionJoueur, GAUCHE);
                break;
        }
        break;
}

        // On efface l'�cran (rectangle blanc)
        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));

        // On place tous les objets (blit)

        for (i = 0 ; i < NB_BLOCS_LARGEUR ; i++)
        {
            for (j = 0 ; j < NB_BLOCS_HAUTEUR ; j++)
            {
                position.x = i * TAILLE_BLOC;
                position.y = j * TAILLE_BLOC;

                switch(carte[i][j])
                {
                    case MUR:
                        SDL_BlitSurface(mur, NULL, ecran, &position);
                        break;
                    case VIDE:
                        SDL_BlitSurface(caseVide, NULL, ecran, &position);
                        break;
                    case AGENT:
                        SDL_BlitSurface(agent, NULL, ecran, &position);
                        break;
                }
            }
        }


        // On place l'agent
        position.x = positionJoueur.x * TAILLE_BLOC;
        position.y = positionJoueur.y * TAILLE_BLOC;
        SDL_BlitSurface(agentActuel, NULL, ecran, &position);



        SDL_Flip(ecran);
    }

    // D�sactivation de la r�p�tition des touches
    SDL_EnableKeyRepeat(0, 0);

    // Lib�ration des surfaces
    SDL_FreeSurface(mur);
    SDL_FreeSurface(caseVide);
    SDL_FreeSurface(agent);
    for (i = 0 ; i < 4 ; i++)
        SDL_FreeSurface(agent[i]);
}

void deplacerJoueur(int carte[][NB_BLOCS_HAUTEUR], SDL_Rect *pos, int direction)
{
    switch(direction)
    {
        case HAUT:
            if (pos->y - 1 < 0) // Si le joueur d�passe l'�cran, on arr�te
                break;
            if (carte[pos->x][pos->y - 1] == MUR) // S'il y a un mur, on arr�te
                break;
            pos->y--; // On peut enfin faire monter le joueur (oufff !)
            break;


        case BAS:
            if (pos->y + 1 >= NB_BLOCS_HAUTEUR)
                break;
            if (carte[pos->x][pos->y + 1] == MUR)
                break;
            pos->y++;
            break;


        case GAUCHE:
            if (pos->x - 1 < 0)
                break;
            if (carte[pos->x - 1][pos->y] == MUR)
                break;
            pos->x--;
            break;


        case DROITE:
            if (pos->x + 1 >= NB_BLOCS_LARGEUR)
                break;
            if (carte[pos->x + 1][pos->y] == MUR)
                break;
            pos->x++;
            break;
    }
}





int main(int argc, char *argv[])
{
    SDL_Surface *ecran = NULL, *menu = NULL;
    SDL_Rect positionMenu;
    SDL_Event event;

    int continuer = 1;

    SDL_Init(SDL_INIT_VIDEO);

    SDL_WM_SetIcon(IMG_Load("agent_bas.bmp"), NULL); // A charger avant SDL_SetVideoMode
    ecran = SDL_SetVideoMode(LARGEUR_FENETRE, HAUTEUR_FENETRE, 32, SDL_HWSURFACE | SDL_FULLSCREEN | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("007 The Battle Royale Game", NULL);

    menu = IMG_Load("Home.bmp");
    positionMenu.x = 0;
    positionMenu.y = 0;

    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_ESCAPE: // Arr�t du jeu
                        continuer = 0;
                        break;
                    case SDLK_KP1: // Lancement du jeu
                        jouer(ecran);
                        break;
                }
                break;
        }

        // Effacement de l'�cran
        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0));
        SDL_BlitSurface(menu, NULL, ecran, &positionMenu);
        SDL_Flip(ecran);
    }

    SDL_FreeSurface(menu);
    SDL_Quit();

    return EXIT_SUCCESS;
}
